create definer = root@localhost view user_u2 as
select `test`.`user`.`id` AS `id`, `test`.`user`.`name` AS `name`, `test`.`user`.`phone` AS `phone`
from `test`.`user`
where (`test`.`user`.`id` <= 10);

