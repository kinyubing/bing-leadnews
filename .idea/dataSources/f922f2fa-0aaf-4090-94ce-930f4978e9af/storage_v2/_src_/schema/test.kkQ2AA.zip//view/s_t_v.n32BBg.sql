create definer = root@localhost view s_t_v as
select `s`.`id` AS `id`, `s`.`name` AS `name`, `c`.`c_name` AS `c_name`
from `test`.`student` `s`
         join `test`.`course` `c`
         join `test`.`student_course` `s_c`
where ((`s`.`id` = `s_c`.`s_s_id`) and (`s_c`.`c_c_id` = `c`.`c_id`));

