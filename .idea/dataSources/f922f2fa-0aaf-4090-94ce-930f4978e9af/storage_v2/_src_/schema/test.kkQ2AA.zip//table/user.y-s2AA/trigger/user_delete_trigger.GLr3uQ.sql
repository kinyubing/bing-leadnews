create definer = root@localhost trigger user_delete_trigger
    after delete
    on user
    for each row
begin 
  insert into user_logs values(null,'delete',now(),old.id,old.name,old.phone,old.address,'旧数据');
end;

