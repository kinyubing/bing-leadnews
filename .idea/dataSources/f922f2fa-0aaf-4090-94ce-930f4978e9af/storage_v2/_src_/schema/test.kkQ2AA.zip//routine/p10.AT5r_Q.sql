create
    definer = root@localhost procedure p10(IN uage int)
begin    -- 游标的声明要在普通变量的后面
-- 声明一些变量来存放结果集的字段
   declare u_id int;
	 declare u_age int;
	 declare u_name varchar(255);
-- 游标声明,存储查询结果集
   declare tb_user_cursor cursor for select * from tb_user where age<=uage;
-- 声明条件处理程序 exit continue 没有找到数据时退出循环并且关闭游标
   declare exit handler for not found close tb_user_cursor;
-- 创建一张新表
   create table tb_user_info (id int primary key auto_increment,age int,name varchar(255));
-- 打开游标
   open tb_user_cursor;
-- 获取游标记录 插入到新表中
   while(true) do 
	   fetch tb_user_cursor into u_id,u_age,u_name;  -- 获取记录赋值给变量
		 insert into tb_user_info values(u_id,u_age,u_name); 
	 end while;

end;

