create definer = root@localhost trigger user_insert_trigger
    after insert
    on user
    for each row
begin 
  insert into user_logs values(null,'insert',now(),new.id,new.name,new.phone,new.address,'新数据');
end;

