create
    definer = root@localhost procedure p9(IN n int)
begin 
 declare total int default 0;
 sum:loop 
 if(n<=0) then leave sum;
 end if;
 if(n%2=1) then 
   set n=n-1;
	 iterate sum;
 end if;
 set total=total+n;
 set n=n-1;
 end loop sum;
 select total;
end;

