create
    definer = root@localhost procedure p5(IN month int)
begin 
   declare result varchar(10);
	 case 
	     when month>=1 and month<=3 then 
			    set result='第一季度';
			  when month>=4 and month<=6 then 
			    set result='第二季度';
				when month>=7 and month<=9 then 
			    set result='第三季度';
				when month>=10 and month<=12 then 
			    set result='第四季度';
				else set result='非法参数';
		end case;
		select concat(month,'所属的季度为:',result);  -- concat()字符串拼接函数
end;

