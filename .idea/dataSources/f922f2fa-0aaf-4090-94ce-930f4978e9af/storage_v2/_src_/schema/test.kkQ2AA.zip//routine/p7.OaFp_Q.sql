create
    definer = root@localhost procedure p7(IN n int)
begin 
 declare total int default 0;
   repeat
	   set total=total+n;
		 set n=n-1;
	 until n<=0
	 end repeat;
	 select total;
end;

