create
    definer = root@localhost procedure p8(IN n int)
begin 
  declare total int default 0;
	sum:loop   -- 为loop循环起名字
	  if(n<=0) then leave sum;
		end if;
	 set total=total+n;
	 set n=n-1;
	end loop sum;
	select total;
end;

