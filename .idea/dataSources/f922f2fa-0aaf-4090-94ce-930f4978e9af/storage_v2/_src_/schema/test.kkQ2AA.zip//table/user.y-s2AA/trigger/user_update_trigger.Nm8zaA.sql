create definer = root@localhost trigger user_update_trigger
    after update
    on user
    for each row
begin 
  insert into user_logs values(null,'update',now(),old.id,old.name,old.phone,old.address,'新数据');
	insert into user_logs values(null,'update',now(),new.id,new.name,new.phone,new.address,'旧数据');
end;

