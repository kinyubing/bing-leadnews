create
    definer = root@localhost procedure p2()
begin 
  -- 变量声明
  declare stu_count int;
	-- 变量赋值
  set stu_count=100;
  -- 变量使用
	select stu_count;
end;

