create
    definer = root@localhost procedure p6(IN n int)
begin 
 declare total int default 0;
  while(n>0) do 
   set total=total+n;
	 set n=n-1;
  end while;
	select total;
end;

