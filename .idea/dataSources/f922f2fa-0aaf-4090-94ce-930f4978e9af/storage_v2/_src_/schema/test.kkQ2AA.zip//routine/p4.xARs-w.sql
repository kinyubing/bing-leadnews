create
    definer = root@localhost procedure p4(INOUT score double)
begin 
 set score=score/2;
end;

