create
    definer = root@localhost procedure p1()
begin 
  -- 统计student表里的总记录数
	select count(*) from student;
end;

