create definer = root@localhost view v_s_cnt as
select `s`.`Zno` AS `Zno`, count(0) AS `count(*)`
from `lyb`.`student` `s`
group by `s`.`Zno`;

