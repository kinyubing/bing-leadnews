create definer = root@localhost event log_event on schedule
    every '1' MINUTE
        starts '2023-11-02 11:26:45'
    enable
    do
    insert into  eventLog values(CURRENT_TIME);

