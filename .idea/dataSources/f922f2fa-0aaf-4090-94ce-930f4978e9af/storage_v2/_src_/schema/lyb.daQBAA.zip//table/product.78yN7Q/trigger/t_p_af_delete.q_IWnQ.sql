create definer = root@localhost trigger T_p_af_delete
    after delete
    on product
    for each row
    insert into operate (op_name,op_time)values('delete',CURRENT_TIME);

