create definer = root@localhost trigger T_p_bf_inser
    before insert
    on product
    for each row
    insert into operate (op_name,op_time)values('insert',CURRENT_TIME);

