create definer = root@localhost trigger T_p_af_update
    after update
    on product
    for each row
    insert into operate (op_name,op_time)values('update',CURRENT_TIME);

