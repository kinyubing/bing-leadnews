create definer = root@localhost view v_s_sw as
select `s`.`Sno`    AS `Sno`,
       `s`.`Sname`  AS `Sname`,
       `s`.`Ssex`   AS `Ssex`,
       `s`.`Sbirth` AS `Sbirth`,
       `s`.`Zno`    AS `Zno`,
       `s`.`Sclass` AS `Sclass`
from `lyb`.`student` `s`
where (`s`.`Zno` = '1102');

